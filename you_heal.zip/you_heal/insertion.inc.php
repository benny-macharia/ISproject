<?php 
//ADMINISTRATOR Section
//Add a Receptionist
if (isset($_POST['addre'])) {
 $hid = $_POST['hid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $question = $_POST['rq'];
 $answer = $_POST['ra'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql1 = "INSERT INTO `receptionist`(`Hospital_ID`, `Fullname`, `Phone_Number`, `Email_Address`, `Recovery_Question`, `Recovery_Answer`, `Password`) VALUES ('$hid','$fname','$phone','$email','$question','$answer',md5('$password'))";
     mysqli_query($conn, $sql1);
   // var_dump($sql);
   // die();
  header("Location: index.php?receptionistregistration=success");
 }else{
  echo "Hospital does not exist.";
 }
}else{
  echo "Passwords do not match.";
 }
}

//Add a Doctor
if (isset($_POST['addd'])) {
 $hid = $_POST['hid'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $spec = $_POST['spec'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql1 = "INSERT INTO `doctors`(`Hospital_ID`, `Fullname`, `Phone_Number`, `Email_Address`, `Specialty`) VALUES ('$hid','$fname','$phone','$email','$spec')";
     mysqli_query($conn, $sql1);
   // var_dump($sql);
   // die();
  header("Location: index.php?doctorregistration=success");
 }else{
  echo "Hospital does not exist.";
 }
}else{
  echo "Passwords do not match.";
 }
}

//Add a Hospital
if (isset($_POST['addh'])) {
 $loc = $_POST['loc'];
 $hname = $_POST['hname'];

 require_once 'dbconnection.inc.php';

   $sql = "INSERT INTO `hospitals`(`Hospital_Name`, `Location`) VALUES ('$hname','$loc')";
     mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?addhospital=success");
 }

 //Add a Room
if (isset($_POST['addro'])) {
 $hid = $_POST['hid'];
 $loc = $_POST['loc'];
 $rname = $_POST['rname'];
 $stat = $_POST['stat'];

 require_once 'dbconnection.inc.php';

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql = "INSERT INTO `rooms`(`Room_Name`, `Hospital_ID`, `Status`) VALUES ('$rname','$hid','$stat')";
     mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?addroom=success");
 }else{
  echo "Hospital does not exist.";
 }
}

//Delete An Item  
if (isset($_POST['deleted'])) {
  $id = $_POST['id'];
  $item = $_POST['item'];

  $h = 0;
  $ro = 1;
  $d = 2;
  $re = 3; 

require_once 'dbconnection.inc.php';

if ($item == $h) {
    $sql = "DELETE FROM `hospitals` WHERE `Hospital_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?delete=success");
}else if ($item == $ro) {
    $sql = "DELETE FROM `rooms` WHERE `Room_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?delete=success");
}else if ($item == $d) {
    $sql = "DELETE FROM `doctors` WHERE `Doctor_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?delete=success");
}else if ($item == $re) {
    $sql = "DELETE FROM `receptionist` WHERE `Receptionist_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index.php?delete=success");
}else{
  echo "An error occurred.";
}
}

//RECEPTIONIST Section
//Add a Patient
if (isset($_POST['addp'])) {
 $rec = $_POST['rec'];
 $fname = $_POST['fname'];
 $email = $_POST['email'];
 $phone = $_POST['phone'];
 $gen = $_POST['gen'];
 $question = $_POST['rq'];
 $answer = $_POST['ra'];
 $password = $_POST['password'];
 $passwordconfirm = $_POST['cpassword'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {

      $sql = "SELECT * FROM `receptionist` WHERE `Receptionist_ID`='$rec'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql1 = "INSERT INTO `patients`(`Fullname`, `Phone_Number`, `Email_Address`, `Sex`, `Recovery_Question`, `Recovery_Answer`, `Password`) VALUES ('$fname','$phone','$email','$gen','$question','$answer',md5('$password'))";
     mysqli_query($conn, $sql1);
   // var_dump($sql);
   // die();
  header("Location: index1.php?patientregistration=success");
 }else{
  echo "Receptionist does not exist.";
 }
}else{
  echo "Passwords do not match.";
 }
}

//Add an Appointment
if (isset($_POST['adda'])) {
 $hid = $_POST['hid'];
 $rec = $_POST['rec'];
 $pid = $_POST['pid'];
 $dt = $_POST['dt'];
 $stat = $_POST['stat'];

 require_once 'dbconnection.inc.php';

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

             $sql1 = "SELECT * FROM `receptionist` WHERE `Receptionist_ID`='$rec'";

        $query1 = mysqli_query($conn,$sql1);

        if(mysqli_num_rows($query1) > 0){

        $sql2 = "SELECT * FROM `patients` WHERE `Patient_ID`='$pid'";

        $query2 = mysqli_query($conn,$sql2);

        if(mysqli_num_rows($query2) > 0){

   $sql3 = "INSERT INTO `appointments`(`Patient_ID`, `Hospital_ID`, `Receptionist_ID`, `Date_Time`, `Status`) VALUES ('$pid','$hid','$rec','$dt','$stat')";
     mysqli_query($conn, $sql3);
   // var_dump($sql);
   // die();
  header("Location: index1.php?addappointment=success");
 }
else{
  echo "Patient does not exist.";
 }
}else{
  echo "Receptionist does not exist.";
 }
}else{
  echo "Hospital does not exist.";
 }
}

//Add a Bill
if (isset($_POST['addb'])) {
 $hid = $_POST['hid'];
 $rec = $_POST['rec'];
 $pid = $_POST['pid'];
 $sid = $_POST['sid'];
 $rid = $_POST['rid'];
 $amo = $_POST['amo'];
 $date = date('Y/m/d');
 $stat = $_POST['stat'];

 require_once 'dbconnection.inc.php';

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

             $sql1 = "SELECT * FROM `receptionist` WHERE `Receptionist_ID`='$rec'";

        $query1 = mysqli_query($conn,$sql1);

        if(mysqli_num_rows($query1) > 0){

        $sql2 = "SELECT * FROM `patients` WHERE `Patient_ID`='$pid'";

        $query2 = mysqli_query($conn,$sql2);

        if(mysqli_num_rows($query2) > 0){

          $sql2 = "SELECT * FROM `medicine_stock` WHERE `Stock_ID`='$sid'";

        $query2 = mysqli_query($conn,$sql2);

        if(mysqli_num_rows($query2) > 0){

   $sql3 = "INSERT INTO `bill`(`Amount`, `Hospital_ID`, `Patient_ID`, `Stock_ID`, `Room_ID`, `Receptionist_ID`, `Status`, `Date`) VALUES ('$amo','$hid','$pid','$sid','$rid','$rec','$stat','$date')";
     mysqli_query($conn, $sql3);
   // var_dump($sql);
   // die();
  header("Location: index1.php?addbill=success");
 }
else{
  echo "Patient does not exist.";
 }
}else{
  echo "Receptionist does not exist.";
 }
}else{
  echo "Hospital does not exist.";
 }
}
}

//Add a Test
if (isset($_POST['addt'])) {
 $hid = $_POST['hid'];
 $did = $_POST['did'];
 $pid = $_POST['pid'];
 $des = $_POST['desc'];
 $res = $_POST['res'];

 require_once 'dbconnection.inc.php';

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

             $sql1 = "SELECT * FROM `doctors` WHERE `Doctor_ID`='$did'";

        $query1 = mysqli_query($conn,$sql1);

        if(mysqli_num_rows($query1) > 0){

        $sql2 = "SELECT * FROM `patients` WHERE `Patient_ID`='$pid'";

        $query2 = mysqli_query($conn,$sql2);

        if(mysqli_num_rows($query2) > 0){

   $sql3 = "INSERT INTO `test`(`Hospital_ID`, `Doctor_ID`, `Patient_ID`, `Description`, `Results`) VALUES ('$hid','$did','$pid','$des','$res')";
     mysqli_query($conn, $sql3);
   // var_dump($sql);
   // die();
  header("Location: index1.php?addtest=success");
 }
else{
  echo "Patient does not exist.";
 }
}else{
  echo "Doctor does not exist.";
 }
}else{
  echo "Hospital does not exist.";
 }
}

//Add a Medicine
if (isset($_POST['addm'])) {
 $med = $_POST['med'];
 $hid = $_POST['hid'];
 $quan = $_POST['quan'];

 require_once 'dbconnection.inc.php';


      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql1 = "INSERT INTO `medicine_stock`(`Medicine_Name`, `Hospital_ID`, `Quantity_Available`) VALUES ('$med','$hid','$quan')";
     mysqli_query($conn, $sql1);
   // var_dump($sql);
   // die();
  header("Location: index1.php?addmedicine=success");
 }else{
  echo "Receptionist does not exist.";
 }
}

//Delete An Item  
if (isset($_POST['deleted'])) {
  $id = $_POST['id'];
  $item = $_POST['item'];

  $p = 0;
  $m = 1;
  $t = 2;
  $b = 3; 
  $a = 4;

require_once 'dbconnection.inc.php';

if ($item == $p) {
    $sql = "DELETE FROM `patients` WHERE `Patient_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index1.php?delete=success");
}else if ($item == $m) {
    $sql = "DELETE FROM `medicine_stock` WHERE `Stock_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index1.php?delete=success");
}else if ($item == $t) {
    $sql = "DELETE FROM `test` WHERE `Test_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index1.php?delete=success");
}else if ($item == $b) {
    $sql = "DELETE FROM `bill` WHERE `Bill_ID` = '$id'";

  mysqli_query($conn, $sql);
   // var_dump($sql);
   // die();
  header("Location: index1.php?delete=success");
}else{
  echo "An error occurred.";
}
}

 //PATIENT Section
 //Set an Appointment
if (isset($_POST['seta'])) {
 $hid = $_POST['hid'];
 $rec = $_POST['rec'];
 $pid = $_POST['pid'];
 $dt = $_POST['dt'];

 require_once 'dbconnection.inc.php';

      $sql = "SELECT * FROM `hospitals` WHERE `Hospital_ID`='$hid'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

             $sql1 = "SELECT * FROM `receptionist` WHERE `Receptionist_ID`='$rec'";

        $query1 = mysqli_query($conn,$sql1);

        if(mysqli_num_rows($query1) > 0){

        $sql2 = "SELECT * FROM `patients` WHERE `Patient_ID`='$pid'";

        $query2 = mysqli_query($conn,$sql2);

        if(mysqli_num_rows($query2) > 0){

   $sql3 = "INSERT INTO `appointments`(`Patient_ID`, `Hospital_ID`, `Receptionist_ID`, `Date_Time`, `Status`) VALUES ('$pid','$hid','$rec','$dt','Active')";
     mysqli_query($conn, $sql3);
   // var_dump($sql);
   // die();
  header("Location: index2.php?setappointment=success");
 }
else{
  echo "Patient does not exist.";
 }
}else{
  echo "Receptionist does not exist.";
 }
}else{
  echo "Hospital does not exist.";
 }
}

//Update a Patient
if (isset($_POST['upp'])) {
 $id = $_POST['id'];
 $fname = $_POST['fname'];
 $phone = $_POST['phone'];

 require_once 'dbconnection.inc.php';

 if ($password == $passwordconfirm) {

      $sql = "SELECT * FROM `patients` WHERE `Patient_ID`='$id'";

        $query = mysqli_query($conn,$sql);

        if(mysqli_num_rows($query) > 0){

   $sql1 = "UPDATE `patients` SET `Fullname`='$fname',`Phone_Number`='$phone' WHERE `Patient_ID` = '$id';";
     mysqli_query($conn, $sql1);
   // var_dump($sql);
   // die();
  header("Location: index1.php?patientregistration=success");
 }else{
  echo "Receptionist does not exist.";
 }
}else{
  echo "Passwords do not match.";
 }
}
 ?>